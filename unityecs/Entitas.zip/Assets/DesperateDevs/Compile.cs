﻿namespace DesperateDevs.CodeGeneration.CodeGenerator.Unity.Editor {

    class Compile {
    }
}
